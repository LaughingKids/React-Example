import React,{Component} from 'react';

class RegisterationSamplesHeader extends Component {

}

module.exports = RegisterationSamplesHeader;