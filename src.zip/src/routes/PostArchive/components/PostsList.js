import React, {Component} from 'react';


class PostsList extends Component {
	render(){
		return (
			<h1>Posts list!</h1>
		)
	}
}

module.exports = PostsList