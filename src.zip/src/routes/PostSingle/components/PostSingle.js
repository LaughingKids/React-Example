import React, {Component} from 'react';


class PostSingle extends Component {
	render(){
		return (
			<h1>Post single!</h1>
		)
	}
}

module.exports = PostSingle