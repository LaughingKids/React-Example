import React,{Component} from 'react';
import MenuUl from '../menu/MenuUl';
import TranslateString from '../translate-string/TranslateString';

class MobileMainNavigation extends Component {
	constructor() {
		super();
		this.state={}
	}
	render() {
		return(
			<div className='MobileMainNavigation mobile'>
			</div>
		)
	}
}

module.exports = MobileMainNavigation;