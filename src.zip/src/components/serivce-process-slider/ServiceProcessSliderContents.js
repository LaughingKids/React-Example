import React,{Component} from 'react';

class ServiceProcessSliderContent extends Component {
	render(){
		return (
			<div className='ServiceProcessSliderContents'>
			</div>
		)
	}
}

module.exports = ServiceProcessSliderContent;